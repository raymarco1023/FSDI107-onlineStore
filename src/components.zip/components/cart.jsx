import "./cart.css";

const Cart = () => {
  return (
    <div className="cart-page">
      <h1>Your Cart</h1>
    </div>
  );
};

export default Cart;
