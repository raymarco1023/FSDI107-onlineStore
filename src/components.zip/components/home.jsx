import "./home.css";

const Home = () => {
  return (
    <div className="home">
      <h1>Party Life</h1>
      <h4>The best online shop</h4>
    </div>
  );
};

export default Home;
