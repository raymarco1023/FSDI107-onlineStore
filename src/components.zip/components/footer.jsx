import "./footer.css";

const Footer = () => {
  return (
    <div className="footer-1">
      <footer>
        <p>All the copyrights reserved &copy; 2022 Ray Garcia</p>
      </footer>
    </div>
  );
};

export default Footer;
